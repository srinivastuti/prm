module.exports = {
    useUniqueHistogramName: false
};
# Master

# 3.1.0 - 3 September, 2020

- Added support for axios responses while using axios-time plugin

# 3.0.0 - 2 September, 2020

### Breaking changes

- Drop Node 6/8 support
